﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Enumerations
{
    public enum World
    {
        Storekeeper,
        SpaceJet,
        Cave,
        Home,

    }
}
