﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Enumerations
{
    enum GameDesign
    {
        Width,
        Height,
        TextColor,
        TextSpeed,
        Design
    }
}
