﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Enumerations
{
    public enum PlayerAttributes
    {
       Health,
       Life,
       Armor,
       Attack,
       Coin,
       Rejuventaion,
       Sack


    }
}
