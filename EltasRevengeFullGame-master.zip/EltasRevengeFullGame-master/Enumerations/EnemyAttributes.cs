﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Enumerations
{
    public enum EnemyAttributes
    {
        Health,
       Life,
       Armor,
       Attack,
       Drop,
       Agro,

    }
}
