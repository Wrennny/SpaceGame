﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Enumerations
{
    public enum Planets
    {
        Clardia,
        Piken,
        Sorflornio,
        Carmencen,
        Nephelia
    }
}
