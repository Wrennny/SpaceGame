﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Enumerations
{
    public enum Items
    {
        
        Gun,//space craft power
        Sword,//Player power
        Jacket,//Player Armor
        Beets, //Rejuventaion
        ScapMetal,//Can be used to sell for coin
        Trinket,// can be used to sell for coin
        Boots,// can be used to sell for coin
        Mineral,// can be used to sell for coin
        Junk, //can be used to sell for coin
    }
}
