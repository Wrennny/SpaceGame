﻿using System;

namespace Enumerations
{
    public enum Decisions
    {
        Yes,
        No,
        

    }
    public enum Barter
    {
        Buy, Sell
    }
    public enum MainMenu
    {
        New_Game,
        Exit
    }
    public enum Encounter
    {
        Attack,
        Defend,
        Heal,
        Run
    }
}
