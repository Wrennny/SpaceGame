﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Enumerations
{
    public enum StoreKeeper
    {
        Gun,//space craft power
        Sword,//Player power
        Jacket,//player Armor
        Elixir,//Player health
        Beet,//Player Rejuventaion
        Immortal_Heart,//Player Life



    }
}
