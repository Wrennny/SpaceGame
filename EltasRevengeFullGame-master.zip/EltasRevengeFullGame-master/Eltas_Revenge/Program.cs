﻿using System;

namespace EltasRevenge
{
    class Program
    {
        static void Main(string[] args)
        {

            GamePlay gamePlay = new GamePlay();
            gamePlay.Start();// start a new game
        }
    }
}
