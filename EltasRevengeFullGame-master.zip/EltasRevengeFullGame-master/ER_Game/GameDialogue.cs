﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Console;

namespace ER_GameLibrary
{
    public class GameDialogue
    {

    }
}
