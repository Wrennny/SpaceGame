﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ER_GameLibrary
{
    public class Encounters
    {
        Random rand = new Random();
        
    }
}
