﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ER_GameLibrary
{
    public class Enemies
    {
        public int Power;
        public int Health;
        public int Armor;
        public int AGRO;

        // need attribute values
        public void VakirLowerMinion()
        {
            //TODO
        }


        public void VIkirUpperMInion()
        {
            //TODO
        }
        public void Audinians()
        {
            //TODO
        }
        public void Ocil()
        {
            //TODO
        }
        public void Thruul()
        {
            //TODO
        }
        public void Yilkir()
        {
            //TODO
        }
        public void Tanqin()
        {
            //TODO
        }
        public void Bhailmaith()
        {
            //TODO
        }
    }
   

}
