using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace EltasRevengeTetHarness
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
