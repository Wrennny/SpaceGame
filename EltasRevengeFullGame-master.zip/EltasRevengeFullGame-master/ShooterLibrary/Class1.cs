﻿using System;

namespace ShooterLibrary
{
    public class Class1
    {
    }
}
